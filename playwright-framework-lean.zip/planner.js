// trimmed for zip version
import fs from 'fs';
import path from 'path';
import { chromium } from 'playwright';
import { getBaseUrl } from './utils/environment.js';

const OUT = path.join(process.cwd(), 'resources', 'testplan.md');

async function main() {
  fs.mkdirSync(path.dirname(OUT), { recursive: true });
  fs.writeFileSync(OUT, '# Auto-generated Test Plan', 'utf8');
  console.log('Planner: Wrote basic testplan');
}
main();
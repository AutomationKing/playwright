// trimmed for zip version
import fs from 'fs';
import path from 'path';

const OUT_DIR = path.join(process.cwd(), 'tests', 'generated');

async function main() {
  fs.mkdirSync(OUT_DIR, { recursive: true });
  fs.writeFileSync(
    path.join(OUT_DIR, 'journey_apply_demo.spec.js'),
    'test("placeholder", () => {});'
  );
  console.log('Generated placeholder test');
}
main();
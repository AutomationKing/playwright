export async function acceptCookieBanner(page) {
  try {
    const btn = page.getByRole('button', { name: /accept|agree|save/i });
    if (await btn.count()) {
      await btn.first().click();
      console.log('Cookie banner accepted');
      return;
    }
  } catch {}
}
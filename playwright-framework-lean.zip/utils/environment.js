export function getBaseUrl() {
  return process.env.BASE_URL || 'https://child-maintenance.service.gov.uk/get-help-arranging-child-maintenance/';
}
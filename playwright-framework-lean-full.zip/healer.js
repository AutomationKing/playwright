import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';

function runTestsWithRetries(retries = 2) {
  console.log('Healer: running tests with retries =', retries);
  try {
    execSync(`npx playwright test --retries=${retries} --reporter=json`, { stdio: 'inherit' });
    console.log('Healer: tests passed or retried successfully');
    return { passed: true };
  } catch (e) {
    console.log('Healer: tests finished with failures (retries applied).');
    return { passed: false };
  }
}

function suggestFixes() {
  console.log('\nHealer: analyzing failure artefacts to suggest fixes...');
  const reportDir = path.join(process.cwd(), 'playwright-report');
  if (!fs.existsSync(reportDir)) {
    console.log('No playwright-report directory found. Run tests with reporter that creates reports.');
    return;
  }
  console.log('Please inspect the Playwright HTML report in', reportDir);
  console.log('Healer suggestions:');
  console.log('- Use getByRole/getByLabel for stable locators');
  console.log('- Add data-test attributes to the app where possible');
  console.log('- Use waitForSelector for dynamic elements');
}

function main() {
  const result = runTestsWithRetries(2);
  if (!result.passed) {
    suggestFixes();
    console.log('\nHealer: re-running tests with `--retries=0` to produce fresh artifacts...');
    try { execSync('npx playwright test --retries=0', { stdio: 'inherit' }); } catch (e) { /* ignore */ }
  }
}

main();

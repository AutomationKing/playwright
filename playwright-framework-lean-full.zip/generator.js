// Generator: creates focused tests for Journey B and additional discovered candidate actions
import fs from 'fs';
import path from 'path';

const PLAN = path.join(process.cwd(), 'resources', 'testplan.md');
const OUT_DIR = path.join(process.cwd(), 'tests', 'generated');

function sanitizeFilename(s) {
  return s.replace(/[^a-z0-9\-]/gi, '_').toLowerCase().slice(0, 60);
}

function buildTestFile(baseUrl, candidateLines) {
  // candidateLines: array of '- Action X: (tag) text -> href'
  const actions = candidateLines.slice(0, 6).map(l => {
    const m = l.match(/\) (.*) -> (.*)/);
    if (m) return { text: m[1].trim(), href: m[2].trim() };
    return null;
  }).filter(Boolean);

  const content = `import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { acceptCookieBanner } from './utils/cookieHelper.js';

const BASE = process.env.BASE_URL || '${baseUrl}';

test.describe('Journey B - Apply for child maintenance (DEMO) - generated', () => {
  test('should navigate to apply and detect Government Gateway (safe stop)', async ({ page }) => {
    await page.goto(BASE);
    await acceptCookieBanner(page);

    // accessibility scan on start
    const startAx = await new AxeBuilder({ page }).analyze();
    console.log('Axe violations (start):', startAx.violations.length);

    // try several candidate selectors to reach apply/start
    const selectors = [
      'text=/apply for child maintenance/i',
      'text=/apply now/i',
      'text=/start now/i',
      'text=/apply/i',
      'a:has-text("Apply")',
      'button:has-text("Apply")'
    ];

    let clicked = false;
    for (const sel of selectors) {
      try {
        const el = page.locator(sel);
        if (await el.count() > 0) {
          await el.first().click({ timeout: 5000 });
          clicked = true;
          console.log('Clicked selector', sel);
          break;
        }
      } catch (e) { /* ignore */ }
    }
    expect(clicked).toBeTruthy();

    await page.waitForLoadState('networkidle');
    const current = page.url();
    console.log('Current URL after click:', current);

    const gatewayPatterns = [/gateway/i, /government\-gateway/i, /signin/i, /login/i, /identity-provider/i, /account/i];
    const isGateway = gatewayPatterns.some(p => p.test(current));
    expect(isGateway || current !== BASE).toBeTruthy();

    // accessibility scan on landing
    const landingAx = await new AxeBuilder({ page }).analyze();
    console.log('Axe violations (landing):', landingAx.violations.length);
  });
});
`;
  return content;
}

function main() {
  if (!fs.existsSync(PLAN)) {
    console.error('Plan not found at', PLAN, '\nRun: npm run plan -- --baseUrl=<your url>'); process.exit(1);
  }
  const md = fs.readFileSync(PLAN, 'utf8');
  // find the first section (start URL)
  const startUrlMatch = md.match(/- URL: (.*)/);
  const baseUrl = startUrlMatch ? startUrlMatch[1].trim() : process.env.BASE_URL || '';
  const lines = md.split('\n');
  // collect candidate lines under the start page
  const startIndex = lines.findIndex(l => l.includes(baseUrl));
  const candidateLines = [];
  for (let i = startIndex; i < Math.min(lines.length, startIndex + 200); i++) {
    const ln = lines[i];
    if (/^- Action \d+:/.test(ln) || /->/.test(ln)) candidateLines.push(ln.trim());
    if (/^## /.test(lines[i+1] || '')) break;
  }

  fs.mkdirSync(OUT_DIR, { recursive: true });
  const content = buildTestFile(baseUrl, candidateLines);
  const filename = 'journey_apply_demo.spec.js';
  fs.writeFileSync(path.join(OUT_DIR, filename), content, 'utf8');
  console.log('Generator: created', filename);
}

main();

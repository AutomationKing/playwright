import { test, expect } from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
import { acceptCookieBanner } from '../../utils/cookieHelper.js';

const BASE = process.env.BASE_URL || 'https://child-maintenance.service.gov.uk/get-help-arranging-child-maintenance/';

test.describe('Journey B - Apply for child maintenance (DEMO)', () => {
  test('should navigate to apply flow and detect Government Gateway (safe stop)', async ({ page }) => {
    await page.goto(BASE);
    await acceptCookieBanner(page);

    const accessibilityScanStart = await new AxeBuilder({ page }).analyze();
    console.log('Axe violations on start page:', accessibilityScanStart.violations.length);

    const applySelectors = [
      'text=/apply for child maintenance/i',
      'text=/apply now/i',
      'text=/start now/i',
      'text=/apply/i',
      'a:has-text("Apply")',
      'button:has-text("Apply")'
    ];

    let clicked = false;
    for (const sel of applySelectors) {
      try {
        const el = page.locator(sel);
        if (await el.count() > 0) {
          await el.first().click({ timeout: 5000 });
          clicked = true;
          console.log('Clicked selector', sel);
          break;
        }
      } catch (e) { }
    }
    expect(clicked).toBeTruthy();

    await page.waitForLoadState('networkidle');
    const current = page.url();
    console.log('Current URL after click:', current);
    const gatewayPatterns = [/gateway/i, /government\-gateway/i, /signin/i, /login/i, /identity-provider/i];
    const isGateway = gatewayPatterns.some(p => p.test(current));
    expect(isGateway || current !== BASE).toBeTruthy();

    const accessibilityScanLanding = await new AxeBuilder({ page }).analyze();
    console.log('Axe violations on landing page:', accessibilityScanLanding.violations.length);
  });
});

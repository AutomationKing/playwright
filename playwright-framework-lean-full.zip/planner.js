// Planner: expanded crawler focused on Journey B and auto-discovery of other journeys
import fs from 'fs';
import path from 'path';
import { chromium } from 'playwright';
import { getBaseUrl } from './utils/environment.js';

const OUT = path.join(process.cwd(), 'resources', 'testplan.md');

async function crawl(startUrl, maxPages = 30) {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  const toVisit = [startUrl];
  const visited = new Set();
  const plan = [];

  while (toVisit.length && visited.size < maxPages) {
    const url = toVisit.shift();
    if (!url || visited.has(url)) continue;
    try {
      await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 20000 });
      visited.add(url);
      const title = await page.title().catch(() => '');
      // find candidate actionable elements
      const actions = await page.$$eval('a, button, input[type=submit], input[type=button]', els =>
        els.slice(0, 30).map(e => ({
          tag: e.tagName.toLowerCase(),
          text: e.innerText?.trim() || e.getAttribute('aria-label') || e.getAttribute('title') || e.getAttribute('href') || '',
          href: e.getAttribute('href') || ''
        }))
      );

      plan.push({ url, title, actions: actions.filter(a => a.text) });

      // collect internal links
      const hrefs = await page.$$eval('a[href]', anchors => anchors.map(a => a.href));
      for (const h of hrefs) {
        try {
          const u = new URL(h);
          const base = new URL(startUrl).origin;
          if (u.origin === base && !visited.has(u.href) && !toVisit.includes(u.href)) toVisit.push(u.href);
        } catch (err) { /* ignore malformed hrefs */ }
      }
    } catch (e) {
      // ignore pages that fail to load
    }
  }

  await browser.close();
  return plan;
}

function planToMarkdown(plan) {
  const lines = ['# Auto-generated Test Plan - Journey B (DEMO)', '', `Generated on: ${new Date().toISOString()}`, ''];
  for (const page of plan) {
    lines.push(`## ${page.title || page.url}`);
    lines.push('');
    lines.push(`- URL: ${page.url}`);
    lines.push('');
    lines.push('### Actions');
    for (const [i, a] of (page.actions || []).entries()) {
      lines.push(`- Action ${i + 1}: (${a.tag}) ${a.text} -> ${a.href || 'inline'}`);
    }
    lines.push('');
  }
  return lines.join('\n');
}

async function main() {
  const base = process.argv.find(a => a.startsWith('--baseUrl='))?.split('=')[1] || getBaseUrl();
  console.log('Planner: crawling', base);
  const plan = await crawl(base, 50);
  const md = planToMarkdown(plan);
  fs.mkdirSync(path.dirname(OUT), { recursive: true });
  fs.writeFileSync(OUT, md, 'utf8');
  console.log('Planner: test plan written to', OUT);
}

main().catch(err => { console.error(err); process.exit(1); });

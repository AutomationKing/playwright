export async function acceptCookieBanner(page) {
  try {
    const btn = page.getByRole('button', { name: /accept|agree|save|yes|ok/i });
    if (await btn.count()) {
      await btn.first().click({ timeout: 3000 });
      console.log('Cookie banner accepted');
      return true;
    }
  } catch (e) { /* ignore */ }

  // fallback: common GOV.UK selector
  try {
    const sel = 'button.govuk-button, button#govuk-cookie-banner, .govuk-cookie-banner__button';
    const el = await page.locator(sel).first();
    if (await el.count()) {
      const text = await el.innerText().catch(() => '');
      if (/accept|agree|save|ok/i.test(text)) {
        await el.click();
        console.log('Cookie banner accepted (fallback)');
        return true;
      }
    }
  } catch (e) { /* ignore */ }

  return false;
}

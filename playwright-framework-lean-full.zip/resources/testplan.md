# Auto-generated Test Plan - Journey B (DEMO)

Generated on: 2025-10-28T00:00:00.000Z

## Get help arranging child maintenance - Start page

- URL: https://child-maintenance.service.gov.uk/get-help-arranging-child-maintenance/

### Actions
- Action 1: (a) Apply for child maintenance -> /apply-for-child-maintenance
- Action 2: (a) Get help -> /get-help
- Action 3: (button) Start now -> inline
